#include<stdio.h>

main()
{
	int q1;
	
	printf("Q1: CSS stands for Cascading Stylesheet?");
	printf("\n1-True\n2-False ");
	
	scanf("%d",&q1);
	if(q1 == 1)
	{
		printf("\n\nCorrect");
	}
	else
	{
		printf("\n\nIncorrect");
	}
	
}

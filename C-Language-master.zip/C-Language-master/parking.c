#include<stdio.h>

main()
{
	int choice;
	while(1)
	{
		printf("1-Car\n2-Bike\n3-View Parking");
		scanf("%d",&choice);
	}
}
